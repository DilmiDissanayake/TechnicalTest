//message1
/*document.addEventListener("DOMContentLoaded", function(){
	const inputArea=document.getElementById("inputArea");
	
	inputArea.addEventListener("focus",function(){
		inputArea.setAttribute("placeholder","Please type your first name.");
	});
	inputArea.addEventListener("input",function(){
		inputArea.setAttribute("placeholder","");
	});
});*/

//email validation
const inputEmail=document.getElementById("inputEmail");
const errorText=document.getElementById("errorText");

inputEmail.addEventListener("input",function(){
	const email=inputEmail.value;
	if(!isValidEmail(email)){
	errorText.textContent="Invalid email address";
	}
	else{
		errorText.textContent="";
	}
});

function isValidEmail(email){
	const emailPattern=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
	return emailPattern.test(email);
}